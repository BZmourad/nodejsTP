const mongoose=require("mongoose");

const carSchema=mongoose.Schema({
    name:String,
    marque:String,
},
{ timestamps: true })
const car=mongoose.model("car",carSchema);
module.exports=car;