const Car = require("../database/model/car");

const env = require("dotenv");

env.config();

// Create and Save a new Car
exports.createCar = (req, res) => {
    // Validate request
    if (!req.body.name) {
      res.status(400).send({ message: "Content can not be empty!" });
      return;
    }
  
    // Create a Car
    const car = new Car({
      name: req.body.name,
      marque: req.body.marque,
    });
  
    // Save Car in the database
    car
      .save(car)
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while creating the Car."
        });
      });
};
  
  // Retrieve all Cars from the database.
exports.findAllCars = (req, res) => {  
    Car.find()
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving cars."
        });
      });
};
  
  // Find a single Car with an id
exports.findOneCar = (req, res) => {
    const id = req.params.id;
    Car.findById(id)
      .then(data => {
        if (!data)
          res.status(404).send({ message: "Not found Car with id " + id });
        else res.send(data);
      })
      .catch(err => {
        res
          .status(500)
          .send({ message: "Error retrieving Car with id=" + id });
      });
};
  
  // Update a Car by the id in the request
exports.updateCar = (req, res) => {
    if (!req.body) {
        return res.status(400).send({
            message: "Data to update can not be empty!"
        });
    }
  
    const id = req.params.id;
  
    Car.findByIdAndUpdate(id, req.body, { useFindAndModify: false })
      .then(data => {
        if (!data) {
          res.status(404).send({
            message: `Cannot update Car with id=${id}. Maybe Car was not found!`
          });
        } else res.send({ message: "Car was updated successfully." });
      })
      .catch(err => {
        res.status(500).send({
          message: "Error updating Car with id=" + id
        });
      });
};
  
  // Delete a Car with the specified id in the request
exports.deleteCar = (req, res) => {
    const id = req.params.id;
  
    Car.findByIdAndDelete(id, { useFindAndModify: false })
      .then(data => {
        if (!data) {
          res.status(404).send({
            message: `Cannot delete Car with id=${id}. Maybe Car was not found!`
          });
        } else {
          res.send({
            message: "Car was deleted successfully!"
          });
        }
      })
      .catch(err => {
        res.status(500).send({
          message: "Could not delete Car with id=" + id
        });
      });
};
