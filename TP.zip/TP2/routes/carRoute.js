const express = require("express");

const carController = require("../controller/carController");

const router = express.Router();

// Create a new Car
router.post("/", carController.createCar);

// Retrieve all Cars
router.get("/", carController.findAllCars);

// Retrieve a single Car with id
router.get("/:id", carController.findOneCar);

// Update a Car with id
router.put("/:id", carController.updateCar);

// Delete a Car with id
router.delete("/:id", carController.deleteCar);

module.exports = router;